# Nexo — app de mensagens

Nexo é um app de mensagens por comunidades: servidores, canais de texto e
mensagens diretas, no estilo Discord — visual clean, escuro, com acento
verde-água/azul, tipografia Outfit + Inter.

## O que já funciona agora (sem instalar nada)

Abra `index.html` num navegador (duplo clique no arquivo, ou veja "Testar
localmente" abaixo) e você terá um app **de verdade**, funcional:

- Criar perfil (nome + cor de avatar), salvo no aparelho
- Vários servidores (comunidades), cada um com vários canais de texto
- Criar novos servidores e novos canais
- Mensagens diretas (DMs) com outros contatos
- Enviar mensagens, com respostas automáticas simuladas (para você sentir
  o fluxo de conversa em tempo real, mesmo sozinho)
- Lista de membros online/offline por servidor
- Layout 100% responsivo: no celular vira navegação por abas (Servidores /
  Canais / Conversa / Membros), igual um app nativo
- Funciona **offline** depois do primeiro carregamento (service worker)
- Instalável como app (Adicionar à tela inicial) em Android e Desktop

## Testar localmente

Navegadores bloqueiam alguns recursos (como o service worker) quando o
arquivo é aberto direto com `file://`. Para testar 100% igual a produção,
sirva a pasta com um servidor local simples:

```bash
cd nexo-app
python3 -m http.server 8080
# abra http://localhost:8080 no navegador (ou no celular, mesma rede Wi-Fi,
# usando o IP do computador em vez de localhost)
```

## ⚠️ Importante sobre "app funcional" e a Play Store

Este pacote entrega um **app front-end completo e funcional**: toda a
interface, navegação, criação de servidores/canais e envio de mensagens
funcionam de verdade. O que ele **não inclui** — porque exige
infraestrutura própria, fora do que cabe num arquivo estático — é o
**backend de tempo real** que faria duas pessoas diferentes, em
aparelhos diferentes, conversarem uma com a outra. Hoje as mensagens
ficam salvas só no aparelho de cada pessoa (localStorage) e as
"respostas automáticas" são simuladas para dar a sensação de conversa.

Isso é assim para **qualquer** clone de Discord/WhatsApp: nenhum app de
mensagens real funciona sem um servidor de backend. Abaixo estão os dois
passos que faltam para ele virar um produto publicável de verdade.

### Passo 1 — Ligar a um backend real (mensagens entre pessoas de verdade)

A forma mais rápida, sem precisar programar um servidor do zero:

1. Crie um projeto grátis no **[Firebase](https://firebase.google.com/)**
   (Google) ou no **[Supabase](https://supabase.com/)**.
2. Ative o banco em tempo real (Firestore/Realtime Database no Firebase,
   ou Postgres + Realtime no Supabase) e a Autenticação.
3. No `app.js`, troque as funções `load()`, `save()`, `sendMessage()` e
   `maybeAutoReply()` para ler/escrever nesse banco em vez do
   `localStorage` — os SDKs deles têm métodos de "escutar mudanças em
   tempo real" que substituem exatamente a função `maybeAutoReply`.
4. Isso é um trabalho de programação real (não é automático); se quiser,
   posso te ajudar a implementar essa parte também, com um serviço
   específico.

### Passo 2 — Transformar em app Android para a Play Store

Como o app já é um **PWA** (tem `manifest.json` + `sw.js` + ícones nos
tamanhos certos), o caminho mais simples e 100% aceito pelo Google é
gerar uma **TWA (Trusted Web Activity)** — um app Android real que abre
seu PWA em tela cheia, sem barra de navegador:

1. Publique os arquivos desta pasta em um domínio com HTTPS (Firebase
   Hosting, Vercel, Netlify ou GitHub Pages — todos têm plano grátis).
2. Acesse **[pwabuilder.com](https://www.pwabuilder.com/)**, cole a URL
   do site publicado.
3. Clique em "Package for stores" → **Android** → baixe o pacote `.aab`
   já assinado (o PWABuilder gera tudo, inclusive o ícone adaptativo a
   partir do `manifest.json`).
4. Crie uma conta de desenvolvedor Google Play (taxa única de US$25) em
   **play.google.com/console**.
5. Crie um novo app, preencha a ficha da loja (nome "Nexo", descrição,
   capturas de tela, política de privacidade — obrigatória mesmo para
   apps simples) e envie o `.aab` gerado no passo 3.
6. Envie para revisão. O Google costuma levar de algumas horas a poucos
   dias para aprovar.

Alternativas ao PWABuilder: **Bubblewrap** (CLI oficial do Google para
gerar TWAs) ou empacotar com **Capacitor**, se preferir ter o projeto
Android completo no seu computador para customizar código nativo.

## Estrutura dos arquivos

```
nexo-app/
├── index.html          → página principal
├── style.css            → todo o visual (tema, cores, responsivo)
├── app.js                → toda a lógica (dados, telas, interações)
├── manifest.json        → configuração do PWA (nome, ícones, cores)
├── sw.js                 → service worker (cache offline)
├── icons/                → SVGs personalizados + ícones PNG do app
│   ├── logo.svg, hash.svg, send.svg, mic.svg, plus.svg, settings.svg,
│   │   search.svg, members.svg, dm.svg, emoji.svg, attach.svg, bell.svg,
│   │   close.svg, back.svg, check.svg, home.svg, moon.svg, mute.svg
│   ├── icon-192.png, icon-512.png            → ícone do app (lojas/atalhos)
│   └── icon-512-maskable.png                  → ícone adaptativo Android
└── README.md
```

## Personalizar

- **Cores/identidade**: variáveis no topo de `style.css` (`:root { ... }`)
- **Nome do app**: `manifest.json` (`name`, `short_name`) e `<title>` do
  `index.html`
- **Dados de exemplo** (servidores/canais/contatos iniciais): função
  `seedState()` no topo de `app.js`
