/* ============================================================
   NEXO — app.js
   App de mensagens por comunidades (servidores/canais) + DMs.
   Funciona 100% no dispositivo: os dados ficam salvos em
   localStorage. Para produção real (mensagens entre pessoas
   diferentes em tempo real) é preciso ligar isto a um backend
   — ver README.md, seção "Ligar a um backend real".
   ============================================================ */

const STORAGE_KEY = 'nexo_state_v1';
const AVATAR_COLORS = ['#3EE8B5','#2E9BE0','#8B7CF6','#F0596B','#F6B24A','#4ADE80','#F472B6','#60A5FA'];

/* ---------------- Dados iniciais de demonstração ---------------- */
function seedState(user){
  return {
    user,
    activeServerId: 'srv-nexo',
    activeChannelId: 'ch-geral',
    activeDmId: null,
    view: 'channel', // 'channel' | 'dm'
    servers: [
      {
        id:'srv-nexo', name:'Comunidade Nexo', initials:'CN',
        members:[
          {id:'m1',name:'Lu Andrade',color:'#F0596B',online:true,role:'Admin'},
          {id:'m2',name:'Théo Ramos',color:'#F6B24A',online:true,role:'Moderador'},
          {id:'m3',name:'Bia Souza',color:'#4ADE80',online:false,role:'Membro'},
        ],
        channels:[
          {id:'ch-geral', name:'geral', messages:[
            {authorId:'m1',text:'Bem-vindo(a) à Comunidade Nexo! 👋 Fique à vontade pra se apresentar aqui.',time:'09:12'},
            {authorId:'m2',text:'Se precisar de ajuda com alguma coisa, é só chamar no #ajuda.',time:'09:14'},
          ]},
          {id:'ch-ajuda', name:'ajuda', messages:[
            {authorId:'m3',text:'Alguém sabe como mudar o tema do app?',time:'08:40'},
          ]},
          {id:'ch-random', name:'random', messages:[]},
        ]
      },
      {
        id:'srv-dev', name:'Devs Nexo', initials:'DN',
        members:[
          {id:'m4',name:'Caio Ferraz',color:'#8B7CF6',online:true,role:'Admin'},
          {id:'m5',name:'Nina Alves',color:'#60A5FA',online:false,role:'Membro'},
        ],
        channels:[
          {id:'ch-dev-geral', name:'geral', messages:[
            {authorId:'m4',text:'Deploy da versão 1.2 foi pro ar agora de manhã 🚀',time:'07:55'},
          ]},
          {id:'ch-dev-bugs', name:'bugs', messages:[]},
        ]
      }
    ],
    dms:[
      {id:'dm1', name:'Lu Andrade', color:'#F0596B', online:true, messages:[
        {from:'them', text:'Oi! Vi sua mensagem no #geral, tudo certo?', time:'09:20'},
      ]},
      {id:'dm2', name:'Caio Ferraz', color:'#8B7CF6', online:true, messages:[]},
      {id:'dm3', name:'Nina Alves', color:'#60A5FA', online:false, messages:[]},
    ]
  };
}

let state = load();

function load(){
  try{
    const raw = localStorage.getItem(STORAGE_KEY);
    if(raw) return JSON.parse(raw);
  }catch(e){}
  return null;
}
function save(){
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

/* ---------------- Helpers ---------------- */
const $ = sel => document.querySelector(sel);
const $$ = sel => Array.from(document.querySelectorAll(sel));
function icon(name, cls){
  return `<img class="icon ${cls||''}" src="icons/${name}.svg" alt="">`;
}
function initials(name){
  return name.trim().split(/\s+/).slice(0,2).map(w=>w[0]).join('').toUpperCase();
}
function nowTime(){
  const d = new Date();
  return d.getHours().toString().padStart(2,'0')+':'+d.getMinutes().toString().padStart(2,'0');
}
function findServer(id){ return state.servers.find(s=>s.id===id); }
function findChannel(server, id){ return server.channels.find(c=>c.id===id); }
function findDm(id){ return state.dms.find(d=>d.id===id); }

/* ---------------- Autenticação simples (perfil local) ---------------- */
function renderAuth(){
  const root = $('#root');
  root.innerHTML = `
  <div class="auth-screen">
    <div class="auth-card">
      <div class="auth-logo"><img src="icons/logo.svg" alt="Nexo"></div>
      <h1>Entrar no Nexo</h1>
      <p class="lead">Crie seu perfil para começar a conversar. Tudo fica salvo neste dispositivo.</p>
      <label class="field-label">Como podemos te chamar?</label>
      <div class="field"><input id="nameInput" maxlength="24" placeholder="Seu nome" /></div>
      <label class="field-label">Escolha uma cor de avatar</label>
      <div class="color-row" id="colorRow"></div>
      <button class="btn-primary" id="enterBtn">Entrar</button>
      <p class="auth-foot">Nexo — mensagens simples, rápidas e suas.</p>
    </div>
  </div>`;

  const row = $('#colorRow');
  let selected = AVATAR_COLORS[0];
  AVATAR_COLORS.forEach((c,i)=>{
    const dot = document.createElement('div');
    dot.className = 'color-dot' + (i===0?' selected':'');
    dot.style.background = c;
    dot.onclick = ()=>{
      $$('.color-dot').forEach(d=>d.classList.remove('selected'));
      dot.classList.add('selected');
      selected = c;
    };
    row.appendChild(dot);
  });

  $('#enterBtn').onclick = ()=>{
    const name = $('#nameInput').value.trim();
    if(!name){ $('#nameInput').focus(); return; }
    const user = { name, color: selected, tag: '#'+Math.floor(1000+Math.random()*9000) };
    state = seedState(user);
    save();
    renderApp();
  };
  $('#nameInput').addEventListener('keydown', e=>{ if(e.key==='Enter') $('#enterBtn').click(); });
}

/* ---------------- App principal ---------------- */
function renderApp(){
  const root = $('#root');
  root.innerHTML = `
    <div id="app">
      <nav class="rail" id="rail"></nav>
      <aside class="sidebar" id="sidebar"></aside>
      <main class="chat" id="chatMain"></main>
      <aside class="members" id="membersPanel"></aside>
    </div>
    <div class="scrim" id="scrim"></div>
    <div class="mobile-nav" id="mobileNav">
      <button data-panel="servers">${icon('home')}<span>Servidores</span></button>
      <button data-panel="channels">${icon('hash')}<span>Canais</span></button>
      <button data-panel="chat">${icon('dm')}<span>Conversa</span></button>
      <button data-panel="members">${icon('members')}<span>Membros</span></button>
    </div>
    <div class="modal-overlay hidden" id="modalOverlay"></div>
  `;
  renderRail();
  renderSidebar();
  renderChat();
  renderMembers();
  bindMobileNav();
}

/* ---------- Server rail ---------- */
function renderRail(){
  const rail = $('#rail');
  let html = `<div class="rail-logo"><img src="icons/logo.svg" alt="Nexo"></div><div class="rail-sep"></div>`;
  state.servers.forEach(s=>{
    const active = state.view==='channel' && s.id===state.activeServerId;
    html += `<button class="server-btn ${active?'active':''}" data-server="${s.id}" title="${escapeHtml(s.name)}">
      <span class="pill"></span>${escapeHtml(s.initials)}
    </button>`;
  });
  html += `<div class="rail-sep"></div>
    <button class="server-btn rail-add" id="addServerBtn" title="Criar servidor">${icon('plus')}</button>`;
  rail.innerHTML = html;

  $$('.server-btn[data-server]').forEach(btn=>{
    btn.onclick = ()=>{
      state.view = 'channel';
      state.activeServerId = btn.dataset.server;
      const srv = findServer(state.activeServerId);
      state.activeChannelId = srv.channels[0].id;
      save();
      renderRail(); renderSidebar(); renderChat(); renderMembers();
      goPanel('channels');
    };
  });
  $('#addServerBtn').onclick = ()=> openCreateServerModal();
}

/* ---------- Sidebar (canais / DMs) ---------- */
function renderSidebar(){
  const sidebar = $('#sidebar');
  if(state.view==='channel'){
    const srv = findServer(state.activeServerId);
    let html = `<div class="sidebar-header"><h1>${escapeHtml(srv.name)}</h1>
      <button class="icon-btn" id="searchBtn">${icon('search')}</button></div>
      <div class="sidebar-body">
      <div class="sidebar-group-label"><span>Canais de texto</span>
        <button class="icon-btn" id="addChannelBtn" style="width:20px;height:20px;">${icon('plus')}</button>
      </div>`;
    srv.channels.forEach(c=>{
      const active = c.id===state.activeChannelId;
      html += `<div class="channel-item ${active?'active':''}" data-channel="${c.id}">
        ${icon('hash')}<span>${escapeHtml(c.name)}</span>
        ${c.messages.length && !active ? '<span class="unread-dot"></span>' : ''}
      </div>`;
    });
    html += `</div>` + sidebarFooter();
    sidebar.innerHTML = html;

    $$('.channel-item').forEach(el=>{
      el.onclick = ()=>{
        state.activeChannelId = el.dataset.channel;
        save();
        renderSidebar(); renderChat();
        goPanel('chat');
      };
    });
    $('#addChannelBtn').onclick = ()=> openCreateChannelModal();
    $('#searchBtn').onclick = ()=> alert('Busca dentro do servidor — funcionalidade de exemplo.');
  } else {
    let html = `<div class="sidebar-header"><h1>Mensagens diretas</h1></div>
      <div class="sidebar-body"><div class="sidebar-group-label"><span>Conversas</span></div>`;
    state.dms.forEach(d=>{
      const active = d.id===state.activeDmId;
      html += `<div class="dm-item ${active?'active':''}" data-dm="${d.id}">
        <span class="dm-avatar" style="background:${d.color}">${initials(d.name)}
          <span class="dm-status ${d.online?'online':''}"></span>
        </span>
        <span>${escapeHtml(d.name)}</span>
      </div>`;
    });
    html += `</div>` + sidebarFooter();
    sidebar.innerHTML = html;

    $$('.dm-item').forEach(el=>{
      el.onclick = ()=>{
        state.activeDmId = el.dataset.dm;
        save();
        renderSidebar(); renderChat();
        goPanel('chat');
      };
    });
  }
}

function sidebarFooter(){
  const u = state.user;
  return `<div class="sidebar-footer">
    <span class="me-avatar" style="background:${u.color}">${initials(u.name)}<span class="me-status"></span></span>
    <div class="me-meta"><div class="me-name">${escapeHtml(u.name)}</div><div class="me-tag">${u.tag}</div></div>
    <button class="icon-btn" id="dmToggleBtn" title="Mensagens diretas">${icon('dm')}</button>
    <button class="icon-btn" id="settingsBtn" title="Configurações">${icon('settings')}</button>
  </div>`;
}
function bindFooterButtons(){
  const dmBtn = $('#dmToggleBtn');
  if(dmBtn) dmBtn.onclick = ()=>{
    state.view = state.view==='dm' ? 'channel' : 'dm';
    if(state.view==='dm' && !state.activeDmId) state.activeDmId = state.dms[0]?.id || null;
    save();
    renderRail(); renderSidebar(); renderChat(); renderMembers();
    goPanel('chat');
  };
  const setBtn = $('#settingsBtn');
  if(setBtn) setBtn.onclick = ()=> openSettingsModal();
}

/* ---------- Chat principal ---------- */
function renderChat(){
  const chat = $('#chatMain');
  let title, sub, messages, avatarColor, headIcon;

  if(state.view==='channel'){
    const srv = findServer(state.activeServerId);
    const ch = findChannel(srv, state.activeChannelId);
    if(!ch){ renderEmptyChat(); return; }
    title = ch.name; headIcon = 'hash';
    sub = srv.name;
    messages = ch.messages.map(m=>{
      const author = m.authorId==='me' ? {name:state.user.name,color:state.user.color} : (srv.members.find(mm=>mm.id===m.authorId) || {name:'Membro',color:'#767C8F'});
      return {name:author.name, color:author.color, text:m.text, time:m.time};
    });
  } else {
    const dm = findDm(state.activeDmId);
    if(!dm){ renderEmptyChat(); return; }
    title = dm.name; headIcon = 'dm'; sub = dm.online ? 'Online' : 'Offline';
    messages = dm.messages.map(m=> m.from==='me'
      ? {name:state.user.name, color:state.user.color, text:m.text, time:m.time}
      : {name:dm.name, color:dm.color, text:m.text, time:m.time});
  }

  chat.innerHTML = `
    <div class="chat-header">
      <button class="icon-btn mobile-back" id="backBtn">${icon('back')}</button>
      ${icon(headIcon)}
      <h2>${escapeHtml(title)}</h2>
      <span class="sub">${escapeHtml(sub)}</span>
      <div class="spacer"></div>
      <button class="icon-btn" id="bellBtn">${icon('bell')}</button>
      <button class="icon-btn" id="membersBtnDesktop" title="Membros">${icon('members')}</button>
    </div>
    <div class="messages" id="messagesEl"></div>
    <div class="typing" id="typingEl"></div>
    <div class="composer-wrap">
      <div class="composer">
        <button class="icon-btn" title="Anexar">${icon('attach')}</button>
        <input id="msgInput" placeholder="Enviar mensagem em ${state.view==='channel'?'#'+title:title}" maxlength="500" />
        <button class="icon-btn" title="Emoji">${icon('emoji')}</button>
        <button class="icon-btn send-btn" id="sendBtn" title="Enviar">${icon('send')}</button>
      </div>
    </div>
  `;

  const msgEl = $('#messagesEl');
  msgEl.innerHTML = messages.length ? messages.map(renderMsg).join('') : emptyMsgState(title);
  msgEl.scrollTop = msgEl.scrollHeight;

  $('#sendBtn').onclick = sendMessage;
  $('#msgInput').addEventListener('keydown', e=>{ if(e.key==='Enter') sendMessage(); });
  $('#bellBtn').onclick = ()=> alert('Notificações — funcionalidade de exemplo.');
  const backBtn = $('#backBtn'); if(backBtn) backBtn.onclick = ()=> goPanel('channels');
  const mBtn = $('#membersBtnDesktop'); if(mBtn) mBtn.onclick = ()=> goPanel('members');

  bindFooterButtons();
}

function emptyMsgState(title){
  return `<div class="empty-state">
    ${icon('hash')}
    <h3>Este é o início da conversa</h3>
    <p>Envie a primeira mensagem em <b>${escapeHtml(title)}</b> e comece o papo.</p>
  </div>`;
}
function renderEmptyChat(){
  $('#chatMain').innerHTML = `<div class="empty-state" style="height:100%;">
    ${icon('dm')}<h3>Selecione uma conversa</h3><p>Escolha um canal ou uma mensagem direta para começar.</p>
  </div>`;
}

function renderMsg(m){
  return `<div class="msg">
    <span class="msg-avatar" style="background:${m.color}">${initials(m.name)}</span>
    <div class="msg-body">
      <div class="msg-head"><span class="msg-name">${escapeHtml(m.name)}</span><span class="msg-time">${m.time}</span></div>
      <div class="msg-text">${escapeHtml(m.text)}</div>
    </div>
  </div>`;
}

function sendMessage(){
  const input = $('#msgInput');
  const text = input.value.trim();
  if(!text) return;
  const time = nowTime();

  if(state.view==='channel'){
    const srv = findServer(state.activeServerId);
    const ch = findChannel(srv, state.activeChannelId);
    ch.messages.push({authorId:'me', text, time});
    // garante que "me" resolve pro usuário atual na renderização
    srv.members.__meCache = true;
  } else {
    const dm = findDm(state.activeDmId);
    dm.messages.push({from:'me', text, time});
  }
  save();
  renderChat();
  maybeAutoReply();
}

/* Corrige lookup do autor "me" nas mensagens de canal */
const _origFindChannel = findChannel;

function maybeAutoReply(){
  const typingEl = $('#typingEl');
  let replier, onDone;
  if(state.view==='channel'){
    const srv = findServer(state.activeServerId);
    const others = srv.members.filter(m=>m.id!=='me');
    if(!others.length) return;
    replier = others[Math.floor(Math.random()*others.length)];
    onDone = (text)=>{
      const ch = findChannel(srv, state.activeChannelId);
      ch.messages.push({authorId: replier.id, text, time: nowTime()});
    };
  } else {
    const dm = findDm(state.activeDmId);
    if(!dm) return;
    replier = {name: dm.name};
    onDone = (text)=>{ dm.messages.push({from:'them', text, time: nowTime()}); };
  }
  const replies = [
    'Boa! 👍', 'Faz sentido.', 'Depois te conto mais detalhes.',
    'kkkk verdade', 'Vou dar uma olhada nisso.', 'Combinado 🙌',
    'Interessante, não tinha pensado nisso.', 'Pode deixar comigo.'
  ];
  if(typingEl) typingEl.textContent = `${replier.name} está digitando...`;
  setTimeout(()=>{
    if(typingEl) typingEl.textContent = '';
    onDone(replies[Math.floor(Math.random()*replies.length)]);
    save();
    renderChat();
  }, 900 + Math.random()*900);
}

/* ---------- Painel de membros ---------- */
function renderMembers(){
  const panel = $('#membersPanel');
  if(state.view!=='channel'){ panel.innerHTML=''; return; }
  const srv = findServer(state.activeServerId);
  const online = srv.members.filter(m=>m.online);
  const offline = srv.members.filter(m=>!m.online);
  function group(label, list){
    if(!list.length) return '';
    return `<h3>${label} — ${list.length}</h3>` + list.map(m=>`
      <div class="member-item">
        <span class="dm-avatar" style="width:28px;height:28px;background:${m.color}">${initials(m.name)}
          <span class="dm-status ${m.online?'online':''}"></span>
        </span>
        <span class="name">${escapeHtml(m.name)}</span>
      </div>`).join('');
  }
  panel.innerHTML = group('Online', online) + group('Offline', offline);
}

/* ---------- Modais ---------- */
function openModal(html){
  const ov = $('#modalOverlay');
  ov.innerHTML = `<div class="modal">${html}</div>`;
  ov.classList.remove('hidden');
  ov.onclick = (e)=>{ if(e.target===ov) closeModal(); };
}
function closeModal(){ $('#modalOverlay').classList.add('hidden'); }

function openCreateServerModal(){
  openModal(`
    <div class="modal-head"><h2>Criar servidor</h2>
      <button class="icon-btn" id="mClose">${icon('close')}</button></div>
    <label class="field-label">Nome do servidor</label>
    <div class="field"><input id="newServerName" placeholder="Ex: Turma da Faculdade" maxlength="30"/></div>
    <button class="btn-primary" id="mCreate">Criar</button>
  `);
  $('#mClose').onclick = closeModal;
  $('#mCreate').onclick = ()=>{
    const name = $('#newServerName').value.trim();
    if(!name) return;
    const id = 'srv-'+Date.now();
    state.servers.push({
      id, name, initials: initials(name),
      members:[{id:'me2', name: state.user.name, color: state.user.color, online:true, role:'Admin'}],
      channels:[{id:'ch-'+Date.now(), name:'geral', messages:[]}]
    });
    state.activeServerId = id;
    state.view='channel';
    state.activeChannelId = state.servers[state.servers.length-1].channels[0].id;
    save();
    closeModal();
    renderRail(); renderSidebar(); renderChat(); renderMembers();
    goPanel('channels');
  };
}

function openCreateChannelModal(){
  openModal(`
    <div class="modal-head"><h2>Criar canal</h2>
      <button class="icon-btn" id="mClose">${icon('close')}</button></div>
    <label class="field-label">Nome do canal</label>
    <div class="field">${icon('hash')}<input id="newChName" placeholder="novo-canal" maxlength="24" style="margin-left:6px;"/></div>
    <button class="btn-primary" id="mCreate">Criar canal</button>
  `);
  $('#mClose').onclick = closeModal;
  $('#mCreate').onclick = ()=>{
    let name = $('#newChName').value.trim().toLowerCase().replace(/\s+/g,'-');
    if(!name) return;
    const srv = findServer(state.activeServerId);
    const id = 'ch-'+Date.now();
    srv.channels.push({id, name, messages:[]});
    state.activeChannelId = id;
    save();
    closeModal();
    renderSidebar(); renderChat();
  };
}

function openSettingsModal(){
  openModal(`
    <div class="modal-head"><h2>Configurações</h2>
      <button class="icon-btn" id="mClose">${icon('close')}</button></div>
    <label class="field-label">Nome de exibição</label>
    <div class="field"><input id="editName" value="${escapeHtml(state.user.name)}" maxlength="24"/></div>
    <label class="field-label">Cor do avatar</label>
    <div class="color-row" id="editColorRow"></div>
    <button class="btn-primary" id="mSave">Salvar alterações</button>
    <p class="auth-foot" id="resetLink" style="cursor:pointer;text-decoration:underline;">Sair e apagar dados locais</p>
  `);
  $('#mClose').onclick = closeModal;
  const row = $('#editColorRow');
  let selected = state.user.color;
  AVATAR_COLORS.forEach(c=>{
    const dot = document.createElement('div');
    dot.className = 'color-dot' + (c===selected?' selected':'');
    dot.style.background = c;
    dot.onclick = ()=>{ $$('#editColorRow .color-dot').forEach(d=>d.classList.remove('selected')); dot.classList.add('selected'); selected=c; };
    row.appendChild(dot);
  });
  $('#mSave').onclick = ()=>{
    const name = $('#editName').value.trim();
    if(name) state.user.name = name;
    state.user.color = selected;
    save();
    closeModal();
    renderApp();
  };
  $('#resetLink').onclick = ()=>{
    if(confirm('Isso vai apagar seu perfil e conversas salvas neste dispositivo. Continuar?')){
      localStorage.removeItem(STORAGE_KEY);
      location.reload();
    }
  };
}

/* ---------- Navegação mobile ---------- */
function bindMobileNav(){
  $$('#mobileNav button').forEach(b=>{
    b.onclick = ()=> goPanel(b.dataset.panel);
  });
  $('#scrim').onclick = ()=> goPanel('chat');
  goPanel('chat', true);
}
function goPanel(panel, silent){
  document.body.classList.remove('panel-servers','panel-channels','panel-members');
  if(panel==='servers') document.body.classList.add('panel-servers');
  if(panel==='channels') document.body.classList.add('panel-channels');
  if(panel==='members') document.body.classList.add('panel-members');
  $$('#mobileNav button').forEach(b=>b.classList.toggle('active', b.dataset.panel===panel));
}

/* ---------- Util ---------- */
function escapeHtml(s){
  return String(s).replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

/* ---------- Boot ---------- */
function boot(){
  if(state && state.user){
    renderApp();
  } else {
    renderAuth();
  }
}
boot();
