const KEY='verdi_v1';
const CONTACTS=['Ana Teste','Bruno Teste','Carla Teste','Diego Teste'];
let S=load();let tab='home';let pixTo=CONTACTS[0];let hidden=false;
function load(){try{return JSON.parse(localStorage.getItem(KEY))}catch(e){return null}}
function save(){try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){}}
const brl=v=>v.toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
const fdate=t=>new Date(t).toLocaleString('pt-BR',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'});
const $=s=>document.querySelector(s);
function toast(m){const t=$('#toast');t.textContent=m;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2200)}
const I={
 home:'<svg viewBox="0 0 24 24"><path d="M3 11l9-8 9 8v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/></svg>',
 list:'<svg viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h10"/></svg>',
 card:'<svg viewBox="0 0 24 24"><rect x="2" y="5" width="20" height="14" rx="3"/><path d="M2 10h20"/></svg>',
 pix:'<svg viewBox="0 0 24 24"><path d="M12 3l9 9-9 9-9-9z"/><path d="M8 12h8"/></svg>',
 dep:'<svg viewBox="0 0 24 24"><path d="M12 4v12M6 10l6 6 6-6M5 20h14"/></svg>',
 pay:'<svg viewBox="0 0 24 24"><path d="M4 4h16v16H4zM8 9h8M8 13h8M8 17h4"/></svg>',
 eye:'<svg viewBox="0 0 24 24" width="20" stroke="#fff" fill="none" stroke-width="2"><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>',
 check:'<svg viewBox="0 0 24 24"><path d="M5 12l5 5 9-10"/></svg>',
 logo:'<svg viewBox="0 0 48 48"><rect width="48" height="48" rx="14" fill="#C9F03A"/><path d="M12 14l12 22 12-22" fill="none" stroke="#0E3B2E" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/></svg>'
};
function add(tx){S.tx.unshift({...tx,t:Date.now()});save()}
function render(){
 const app=$('#app');
 if(!S){app.innerHTML=`<div class="login"><div class="logo">${I.logo}Verdi</div><p>Banco de mentirinha para brincar. Nenhum dinheiro é real.</p><input id="nm" placeholder="Seu nome" autocomplete="off"><input id="ini" type="number" inputmode="decimal" placeholder="Saldo inicial de brincadeira (ex: 1000)"><button class="btn" id="go">Abrir minha conta</button><p style="font-size:12px">Simulação. Não é um banco de verdade e não tem ligação com nenhum banco.</p></div>`;
  $('#go').onclick=()=>{const n=$('#nm').value.trim();if(!n)return toast('Digite seu nome');const v=parseFloat($('#ini').value)||0;
   S={name:n,bal:v,tx:[],card:'4'+Array.from({length:15},()=>Math.floor(Math.random()*10)).join(''),cvv:String(Math.floor(100+Math.random()*900)),limit:2000,used:0};
   if(v>0)add({type:'in',title:'Saldo inicial de brincadeira',amt:v});save();render()};return}
 const first=S.name.split(' ')[0];
 let body='';
 if(tab==='home'){
  body=`<header class="top"><div class="row"><div class="hi">Oi, ${first}</div><button class="eye" id="hid" aria-label="Mostrar ou esconder saldo">${I.eye}</button></div><div class="bal-label">Saldo em conta</div><div class="bal">${hidden?'R$ •••••':brl(S.bal)}</div></header>
  <div class="actions"><button class="act" data-go="pix">${I.pix}Pix</button><button class="act" data-go="dep">${I.dep}Depositar</button><button class="act" data-go="pay">${I.pay}Pagar</button><button class="act" data-go="card">${I.card}Cartão</button></div>
  <div class="screen" style="padding-top:0"><h2>Últimas movimentações</h2>${txs(S.tx.slice(0,5))}</div>`;
 }else if(tab==='ext'){
  body=`<div class="screen"><h2 style="margin-top:6px">Extrato</h2>${txs(S.tx)}<button class="btn ghost" id="reset" style="margin-top:20px">Zerar tudo e recomeçar</button></div>`;
 }else if(tab==='pix'){
  body=`<div class="screen"><h2 style="margin-top:6px">Pix de brincadeira</h2><label>Para quem?</label><div class="chips">${CONTACTS.map(c=>`<button class="chip ${c===pixTo?'on':''}" data-to="${c}">${c}</button>`).join('')}</div><label>Valor</label><input id="pv" type="number" inputmode="decimal" placeholder="0,00"><label>Mensagem (opcional)</label><input id="pm" maxlength="40" placeholder="Ex: pizza de ontem"><br><br><button class="btn" id="dopix">Enviar Pix</button><p class="empty">Só funciona entre contas de teste.</p></div>`;
 }else if(tab==='dep'){
  body=`<div class="screen"><h2 style="margin-top:6px">Depositar dinheiro de mentira</h2><label>Valor</label><input id="dv" type="number" inputmode="decimal" placeholder="0,00"><br><br><button class="btn" id="dodep">Depositar</button></div>`;
 }else if(tab==='pay'){
  body=`<div class="screen"><h2 style="margin-top:6px">Pagar boleto de teste</h2><label>Descrição</label><input id="bd" placeholder="Ex: conta de luz"><label>Valor</label><input id="bv" type="number" inputmode="decimal" placeholder="0,00"><br><br><button class="btn" id="dopay">Pagar com saldo</button></div>`;
 }else if(tab==='card'){
  const n=S.card.replace(/(.{4})/g,'$1 ').trim();
  body=`<div class="screen"><h2 style="margin-top:6px">Cartão virtual</h2><div class="card3d"><b style="font-size:20px">Verdi</b><div class="num">${n}</div><div style="display:flex;justify-content:space-between"><span>${S.name.toUpperCase()}</span><span>CVV ${S.cvv}</span></div></div><p style="margin-top:12px;color:var(--mute);font-size:13px">Número inventado, não funciona em lugar nenhum.</p><h2>Fatura</h2><div class="tx"><span>Usado</span><b>${brl(S.used)}</b></div><div class="tx"><span>Limite disponível</span><b>${brl(S.limit-S.used)}</b></div><label>Compra no cartão</label><input id="cd" placeholder="Descrição"><br><br><input id="cv" type="number" inputmode="decimal" placeholder="Valor"><br><br><button class="btn dark" id="docard">Comprar no crédito</button><button class="btn ghost" id="payfat" style="margin-top:10px">Pagar fatura com saldo</button></div>`;
 }else if(tab==='rec'){
  const r=S.receipt;
  body=`<div class="screen"><div class="receipt"><div class="ok">${I.check}</div><h2 style="margin:0">Pix enviado</h2><div class="bal" style="font-size:28px">${brl(r.amt)}</div><dl><dt>Para</dt><dd>${r.to}</dd><dt>Quando</dt><dd>${fdate(r.t)}</dd>${r.msg?`<dt>Mensagem</dt><dd>${r.msg}</dd>`:''}</dl><div class="fake">COMPROVANTE DE BRINCADEIRA - sem valor real</div></div><br><button class="btn" data-go="home">Voltar ao início</button></div>`;
 }
 const nv=(id,ic,l)=>`<button class="${tab===id?'on':''}" data-go="${id}">${ic}${l}</button>`;
 app.innerHTML=`<div class="sim">SIMULAÇÃO - dinheiro de mentira, nenhum banco real</div>${body}<nav class="nav">${nv('home',I.home,'Início')}${nv('ext',I.list,'Extrato')}${nv('pix',I.pix,'Pix')}${nv('card',I.card,'Cartão')}</nav>`;
 bind();
}
function txs(l){if(!l.length)return '<div class="empty">Nada por aqui ainda.</div>';return l.map(x=>`<div class="tx"><div>${x.title}<small>${fdate(x.t)}</small></div><div class="${x.type}">${x.type==='in'?'+ ':'- '}${brl(x.amt)}</div></div>`).join('')}
function val(id){return parseFloat(($(id).value||'').replace(',','.'))}
function bind(){
 document.querySelectorAll('[data-go]').forEach(b=>b.onclick=()=>{tab=b.dataset.go;render();scrollTo(0,0)});
 document.querySelectorAll('[data-to]').forEach(b=>b.onclick=()=>{pixTo=b.dataset.to;document.querySelectorAll('.chip').forEach(c=>c.classList.toggle('on',c.dataset.to===pixTo))});
 const on=(id,f)=>{const e=$(id);if(e)e.onclick=f};
 on('#hid',()=>{hidden=!hidden;render()});
 on('#reset',()=>{if(confirm('Apagar tudo e recomeçar?')){localStorage.removeItem(KEY);S=null;tab='home';render()}});
 on('#dopix',()=>{const v=val('#pv');if(!(v>0))return toast('Digite um valor');if(v>S.bal)return toast('Saldo insuficiente');
  S.bal-=v;const msg=$('#pm').value.trim();add({type:'out',title:'Pix para '+pixTo,amt:v});S.receipt={amt:v,to:pixTo,msg,t:Date.now()};save();tab='rec';render()});
 on('#dodep',()=>{const v=val('#dv');if(!(v>0))return toast('Digite um valor');S.bal+=v;add({type:'in',title:'Depósito de brincadeira',amt:v});toast('Depositado!');tab='home';render()});
 on('#dopay',()=>{const v=val('#bv');if(!(v>0))return toast('Digite um valor');if(v>S.bal)return toast('Saldo insuficiente');S.bal-=v;add({type:'out',title:'Boleto: '+($('#bd').value||'sem descrição'),amt:v});toast('Boleto pago!');tab='home';render()});
 on('#docard',()=>{const v=val('#cv');if(!(v>0))return toast('Digite um valor');if(v>S.limit-S.used)return toast('Limite insuficiente');S.used+=v;add({type:'out',title:'Cartão: '+($('#cd').value||'compra'),amt:0});S.tx[0].amt=v;save();toast('Compra aprovada!');render()});
 on('#payfat',()=>{if(S.used<=0)return toast('Fatura zerada');if(S.used>S.bal)return toast('Saldo insuficiente');S.bal-=S.used;add({type:'out',title:'Pagamento da fatura',amt:S.used});S.used=0;save();toast('Fatura paga!');render()});
}
render();
