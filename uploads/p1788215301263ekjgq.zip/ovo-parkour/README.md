# 🥚 Ovo Parkour

Um jogo de parkour 2D onde você controla um ovo que precisa pular de plataforma em
plataforma até chegar à bandeira. Se o ovo cair de uma grande altura ou tocar nos
espinhos, ele quebra e o jogo termina!

## Como jogar

1. Abra o arquivo `index.html` em qualquer navegador (Chrome, Firefox, Edge, Safari...).
2. Use as setas ⬅️ ➡️ ou as teclas **A/D** para mover o ovo.
3. Use **Espaço**, **↑** ou **W** para pular.
4. Em celular/tablet, use os botões na tela.
5. Chegue até a bandeira 🚩 para completar a fase.
6. Evite os espinhos e não deixe o ovo cair — se ele quebrar, você perde e pode
   tentar novamente.

## Recursos

- 3 fases com dificuldade crescente.
- Plataformas normais, plataformas móveis e plataformas que desmoronam (crumble).
- Animação de "esmagar/esticar" do ovo ao pular e aterrissar.
- Animação de quebra do ovo ao perder.
- Cronômetro e indicador de fase na tela.
- Funciona 100% offline, sem dependências externas — é um único arquivo HTML
  autocontido (HTML + CSS + JavaScript).

## Arquivos

- `index.html` — o jogo completo (basta abrir no navegador).
